<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CorporativePages extends Model
{
    protected $table = 'corporative_pages';
    protected $guarded = [] ;
}
